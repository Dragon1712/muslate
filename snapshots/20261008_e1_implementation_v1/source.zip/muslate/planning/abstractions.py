"""Action abstractions, expressed as drop-in candidate generators.

Gate 3 asks whether a Semantic-ID hierarchy is worth anything compared with
flattening the problem.  To answer that, the *search* must be held fixed and only
the *candidate generator* varied -- otherwise a difference could come from the
planner rather than from the action space.

Every class here therefore exposes the same tiny interface as
:class:`~muslate.planning.proposal.ProposalPolicy`

    propose(states [B, D]) -> candidates [B, M, K]

so it can be dropped into ``Lookahead``, ``RandomShooting`` or any future planner
unchanged.

Budget accounting is explicit, because the comparison is only meaningful at equal
budget:

* ``M``               candidates handed to the planner (identical across variants)
* ``proposal_cost()`` extra world-model evaluations the generator itself spends
                      while searching (0 for the flat pools, non-zero for the
                      hierarchical ones)

A fair comparison holds ``M + proposal_cost()`` constant, which is what
``scripts/run_gate3.py`` does.
"""

from __future__ import annotations

import numpy as np

from muslate.planning.latent_model import LatentModel
from muslate.planning.sid_map import SIDMap


class SIDProposal:
    """Coarse-to-fine generation over a two-level Semantic-ID hierarchy.

    ``refine_positions == 0`` is the flat one-level variant: sample coarse
    category plans and complete each greedily.  ``refine_positions > 0`` adds
    progressive widening -- only the ``widen`` best coarse plans are carried
    forward and refined item-by-item inside their fixed category structure.

    The refinement is what a flat sampler cannot do: it commits to a coarse
    structure first and only then spends budget on detail, instead of spreading
    the whole budget over coarse combinations.
    """

    def __init__(
        self,
        model: LatentModel,
        n_coarse: int | None = None,
        n_fine: int | None = None,
        n_sampled: int = 64,
        out_size: int = 64,
        widen: int = 4,
        refine_positions: int = 0,
        fine_per_pos: int = 8,
        seed: int = 0,
        temperature: float = 0.7,
        sid_map: SIDMap | None = None,
    ):
        self.model = model
        if sid_map is None:
            if n_coarse is None or n_fine is None:
                raise ValueError(
                    "SIDProposal needs either `sid_map`, or both `n_coarse` and `n_fine`"
                )
            sid_map = SIDMap.uniform(model.n_items, n_coarse, n_fine)
        # `_coarse_plans` builds a length-`slate_size` anchor from the class
        # ranking, so fewer classes than that would fail later with an opaque
        # numpy broadcast error (Review finding N2).  Fail early and clearly.
        if sid_map.n_coarse < model.slate_size:
            raise ValueError(
                f"SIDProposal needs at least slate_size={model.slate_size} classes, "
                f"got {sid_map.n_coarse} (kind={sid_map.kind!r})"
            )
        self.sid_map = sid_map
        self.n_coarse = sid_map.n_coarse
        self.n_sampled = n_sampled
        self.out_size = out_size
        self.widen = widen
        self.refine_positions = refine_positions
        self.fine_per_pos = fine_per_pos
        self.temperature = temperature
        self.rng = np.random.default_rng(seed)

    # -- budget -----------------------------------------------------------
    def proposal_cost(self) -> int:
        refine = self.widen * self.refine_positions * self.fine_per_pos if self.refine_positions else 0
        return self.n_sampled + refine

    def output_size(self) -> int:
        return self.out_size

    # -- helpers ----------------------------------------------------------
    def _softmax(self, x: np.ndarray) -> np.ndarray:
        z = x / max(self.temperature, 1e-6)
        z = z - z.max()
        e = np.exp(z)
        return e / e.sum()

    def _items_in(self, c: int) -> np.ndarray:
        return self.sid_map.items_by_coarse[c]

    def _complete(self, scores: np.ndarray, coarse_plan: np.ndarray) -> np.ndarray:
        """Fill a coarse plan into a concrete slate, greedily, without repeats."""
        slate: list[int] = []
        used: set[int] = set()
        for c in coarse_plan:
            items = self._items_in(int(c))
            order = np.argsort(-scores[items])
            pick = int(items[order[0]])
            for o in order:
                cand = int(items[o])
                if cand not in used:
                    pick = cand
                    break
            used.add(pick)
            slate.append(pick)
        return np.asarray(slate, dtype=np.int64)

    def _coarse_plans(self, coarse_scores: np.ndarray, k: int, n: int) -> np.ndarray:
        plans = np.empty((n, k), dtype=np.int64)
        plans[0] = np.argsort(-coarse_scores)[:k]              # greedy anchor
        probs = self._softmax(coarse_scores)
        for m in range(1, n):
            plans[m] = self.rng.choice(self.n_coarse, size=k, p=probs)
        return plans

    # -- search -----------------------------------------------------------
    def _search_one(self, state: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """state [1, D] -> (evaluated candidates [E, K], their model rewards [E])."""
        k = self.model.slate_size
        scores = self.model.item_scores(state)[0]                       # [N]
        coarse_scores = np.asarray(
            [scores[g].max() for g in self.sid_map.items_by_coarse], dtype=np.float64
        )

        plans = self._coarse_plans(coarse_scores, k, self.n_sampled)
        slates = np.stack([self._complete(scores, p) for p in plans])    # [S, K]
        r = self.model.reward(np.repeat(state, slates.shape[0], axis=0), slates)

        if self.refine_positions == 0:
            return slates, r

        # -- progressive widening: only the best coarse plans get refined ----
        n_widen = min(self.widen, slates.shape[0])
        keep = np.argsort(-r)[:n_widen]
        best = slates[keep].copy()
        best_r = r[keep].copy()

        extra_slates: list[np.ndarray] = []
        extra_r: list[np.ndarray] = []

        for pos in range(min(self.refine_positions, k)):
            cands, owners = [], []
            for w in range(best.shape[0]):
                c = int(self.sid_map.coarse_of[best[w, pos]])
                items = self._items_in(c)
                order = items[np.argsort(-scores[items])][: self.fine_per_pos]
                for it in order:
                    cand = best[w].copy()
                    cand[pos] = it
                    cands.append(cand)
                    owners.append(w)
            if not cands:
                continue
            cands = np.stack(cands)
            cr = self.model.reward(np.repeat(state, cands.shape[0], axis=0), cands)
            extra_slates.append(cands)
            extra_r.append(cr)
            for idx, w in enumerate(owners):
                if cr[idx] > best_r[w]:
                    best_r[w] = cr[idx]
                    best[w] = cands[idx]

        all_slates = np.concatenate([slates] + extra_slates, axis=0)
        all_r = np.concatenate([r] + extra_r, axis=0)
        return all_slates, all_r

    def propose(self, states: np.ndarray) -> np.ndarray:
        states = np.atleast_2d(states)
        b = states.shape[0]
        out = np.empty((b, self.out_size, self.model.slate_size), dtype=np.int64)
        for i in range(b):
            slates, r = self._search_one(states[i : i + 1])
            n_out = min(self.out_size, slates.shape[0])
            order = np.argsort(-r)[:n_out]
            out[i, :n_out] = slates[order]
            if n_out < self.out_size:                       # pad with the anchor
                out[i, n_out:] = slates[order[0]]
        return out
