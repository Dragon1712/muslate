"""Latent-dynamics interface shared by the oracle simulator and the learned
world model.

Everything in :mod:`muslate.planning` is written against :class:`LatentModel`
only, so the *identical* planner code can be run with

* ground-truth dynamics (an upper bound on achievable performance), and
* a learned world model (what we would actually deploy).

That separation is what lets us tell "planning cannot help here" apart from
"our model is too weak to plan with".
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np

from muslate.env import SimState, SlateSim


class LatentModel(ABC):
    """Batch interface over a (learned or true) latent dynamics model."""

    state_dim: int
    n_items: int
    slate_size: int

    @abstractmethod
    def reward(self, states: np.ndarray, slates: np.ndarray) -> np.ndarray:
        """states [B, D], slates [B, K] -> reward [B]."""

    @abstractmethod
    def step(self, states: np.ndarray, slates: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """states [B, D], slates [B, K] -> (reward [B], next_states [B, D])."""

    @abstractmethod
    def item_scores(self, states: np.ndarray) -> np.ndarray:
        """Myopic per-item score used to bias candidate generation. [B, N]."""


class OracleModel(LatentModel):
    """The simulator exposed through the latent-model interface."""

    def __init__(self, sim: SlateSim):
        self.sim = sim
        self.dim = sim.cfg.dim
        self.state_dim = sim.cfg.dim + sim.n_coarse
        self.n_items = sim.n_items
        self.slate_size = sim.slate_size

    # -- state helpers ----------------------------------------------------
    def encode(self, state: SimState) -> np.ndarray:
        return np.concatenate([state.h, state.sat]).astype(np.float64)

    def _split(self, states: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        return states[:, : self.dim], states[:, self.dim :]

    # -- LatentModel ------------------------------------------------------
    def reward(self, states: np.ndarray, slates: np.ndarray) -> np.ndarray:
        h, sat = self._split(states)
        return self.sim.reward_batch(h, sat, slates)

    def step(self, states: np.ndarray, slates: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        h, sat = self._split(states)
        r, h2, s2 = self.sim.step_batch(h, sat, slates)
        return r, np.concatenate([h2, s2], axis=1)

    def item_scores(self, states: np.ndarray) -> np.ndarray:
        h, sat = self._split(states)
        base = h @ self.sim.catalog.item_emb.T                       # [B, N]
        pen = self.sim.lt * self.sim.cfg.sat_penalty * sat[:, self.sim.catalog.item_coarse]
        return base - pen


class CountingModel(LatentModel):
    """Wraps a :class:`LatentModel` and counts model evaluations.

    Different planners spend their budget in structurally different ways -- a
    beam expands ``M`` slates at every level, MCTS spreads the same total over
    simulations, CEM re-samples its elite distribution.  Comparing them at
    "the same nominal budget" is therefore meaningless unless the *actual*
    number of model calls is measured.  This wrapper is what makes the Q3
    comparison honest.

    ``n_slate_evals`` counts reward/dynamics evaluations of concrete slates
    (the expensive ones); ``n_score_calls`` counts item-score queries, which cost
    one vector op per state.
    """

    def __init__(self, inner: LatentModel):
        self.inner = inner
        self.state_dim = inner.state_dim
        self.n_items = inner.n_items
        self.slate_size = inner.slate_size
        self.n_slate_evals = 0
        self.n_score_calls = 0

    def reset(self) -> None:
        self.n_slate_evals = 0
        self.n_score_calls = 0

    def reward(self, states: np.ndarray, slates: np.ndarray) -> np.ndarray:
        self.n_slate_evals += int(np.atleast_2d(slates).shape[0])
        return self.inner.reward(states, slates)

    def step(self, states: np.ndarray, slates: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        self.n_slate_evals += int(np.atleast_2d(slates).shape[0])
        return self.inner.step(states, slates)

    def item_scores(self, states: np.ndarray) -> np.ndarray:
        self.n_score_calls += int(np.atleast_2d(states).shape[0])
        return self.inner.item_scores(states)
