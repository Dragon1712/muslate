"""Training the latent world model from an offline interaction log.

Loss = one-step reward MSE
     + multi-step reward MSE (rolled out through the model's own dynamics)
     + optional latent-state aux MSE (oracle-assisted representation)
     + optional item-score aux MSE (so the proposal policy has a usable prior)
"""

from __future__ import annotations

import copy
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from muslate.config import EnvConfig, LogConfig, WorldModelConfig
from muslate.env.logger import OfflineLog, generate_log
from muslate.env.simulator import SlateSim
from muslate.model.world_model import WorldModel


def get_device(pref: str = "auto") -> torch.device:
    if pref == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(pref)


def true_item_scores(sim: SlateSim, states: np.ndarray) -> np.ndarray:
    """The simulator's myopic per-item score for a batch of latent states [B, D]."""
    d = sim.cfg.dim
    h, sat = states[:, :d], states[:, d:]
    base = h @ sim.catalog.item_emb.T
    pen = sim.lt * sim.cfg.sat_penalty * sat[:, sim.catalog.item_coarse]
    return base - pen


def logs_to_tensors(log: OfflineLog, device: torch.device):
    n_ep = int(log.episode_ids.max()) + 1
    t = log.horizon
    k = log.slate_size
    slates = torch.as_tensor(log.slates, dtype=torch.long, device=device).reshape(n_ep, t, k)
    rewards = torch.as_tensor(log.rewards, dtype=torch.float32, device=device).reshape(n_ep, t)
    states = torch.as_tensor(log.states, dtype=torch.float32, device=device).reshape(n_ep, t, -1)
    return slates, rewards, states


def train_world_model(
    sim: SlateSim,
    log: OfflineLog,
    cfg: WorldModelConfig,
    device: torch.device,
    verbose: bool = True,
) -> WorldModel:
    torch.manual_seed(cfg.seed)
    slates, rewards, states = logs_to_tensors(log, device)
    n_ep = slates.shape[0]

    model = WorldModel(cfg, sim.n_items, sim.slate_size, true_state_dim=states.shape[-1]).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)

    scores_true = torch.as_tensor(
        true_item_scores(sim, log.states), dtype=torch.float32, device=device
    ).reshape(n_ep, log.horizon, sim.n_items)

    gen = torch.Generator(device="cpu").manual_seed(cfg.seed)
    n_batches = max(1, n_ep // cfg.batch_size)

    for epoch in range(cfg.epochs):
        perm = torch.randperm(n_ep, generator=gen)
        total = 0.0
        for bi in range(n_batches):
            idx = perm[bi * cfg.batch_size : (bi + 1) * cfg.batch_size]
            if idx.numel() == 0:
                continue
            sl, rw, st = slates[idx], rewards[idx], states[idx]

            states_seq = model(sl, rw)
            t_len = sl.shape[1]

            loss = cfg.w_reward * F.mse_loss(model.predict_reward(states_seq, sl), rw)

            multi = states_seq.new_zeros(())
            for j in range(1, min(cfg.rollout_depth, t_len - 1) + 1):
                h = states_seq[:, : t_len - j]
                for s in range(j):
                    h = model.step_latent(h, sl[:, s : t_len - j + s])
                r_hat = model.predict_reward(h, sl[:, j:])
                multi = multi + F.mse_loss(r_hat, rw[:, j:])
            loss = loss + cfg.w_multistep * multi / max(cfg.rollout_depth, 1)

            if model.state_head is not None:
                loss = loss + cfg.w_state * F.mse_loss(model.state_head(states_seq), st)

            loss = loss + cfg.w_score * F.mse_loss(model.item_scores(states_seq), scores_true[idx])

            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            total += float(loss.item())

        if verbose and (epoch + 1) % max(1, cfg.epochs // 5) == 0:
            print(f"  [wm] epoch {epoch + 1:>3}/{cfg.epochs}  loss={total / n_batches:.4f}")

    return model


def train_ensemble(
    sim: SlateSim,
    log_cfgs: list[LogConfig] | None,
    cfg: WorldModelConfig,
    device: torch.device,
    verbose: bool = True,
) -> list[WorldModel]:
    """Train ``cfg.n_ensemble`` models on independently logged datasets.

    Data diversity, not just init diversity, is what makes the ensemble
    disagreement a usable epistemic-uncertainty signal.
    """
    models = []
    for i in range(cfg.n_ensemble):
        sub_cfg = copy.deepcopy(cfg)
        sub_cfg.seed = cfg.seed + 1000 * i
        log_cfg = (log_cfgs[i] if log_cfgs else LogConfig(seed=cfg.seed + 1000 * i))
        log_cfg = copy.deepcopy(log_cfg)
        log_cfg.seed = cfg.seed + 1000 * i
        if verbose:
            print(f"[ensemble {i + 1}/{cfg.n_ensemble}] generating log ...")
        log = generate_log(sim, log_cfg)
        models.append(train_world_model(sim, log, sub_cfg, device, verbose=verbose))
    return models


def build_dataset(
    env_cfg: EnvConfig,
    log_cfg: LogConfig,
    path: str | Path | None = None,
) -> tuple[SlateSim, OfflineLog]:
    """Simulator + log, cached on disk if ``path`` is given."""
    sim = SlateSim(env_cfg)
    if path is not None and Path(path).exists():
        return sim, OfflineLog.load(path)
    log = generate_log(sim, log_cfg)
    if path is not None:
        log.save(path)
    return sim, log


# Architecture variations for a heterogeneous ensemble.  ``latent_dim`` is
# deliberately NOT varied: every member must live in the same belief space,
# otherwise the planner cannot feed one state to all of them and the whole
# "ensemble of dynamics models" abstraction collapses.  Everything downstream of
# the belief -- slate encoding capacity, MLP width, multi-step training strength,
# learning rate -- is fair game, and that is where the disagreement comes from.
HETERO_SPECS: list[dict] = [
    dict(slate_emb_dim=32, hidden_dim=64, rollout_depth=1, lr=5e-3),
    dict(slate_emb_dim=64, hidden_dim=128, rollout_depth=3, lr=3e-3),
    dict(slate_emb_dim=96, hidden_dim=256, rollout_depth=5, lr=1e-3),
    dict(slate_emb_dim=48, hidden_dim=96, rollout_depth=2, lr=4e-3),
]


def train_heterogeneous_ensemble(
    sim: SlateSim,
    log_cfgs: list[LogConfig],
    base_cfg: WorldModelConfig,
    device: torch.device,
    specs: list[dict] | None = None,
    verbose: bool = True,
) -> list[WorldModel]:
    """Ensemble whose members differ in architecture, capacity and training.

    Identically-trained members make nearly identical mistakes, so their
    disagreement says little about error (Gate 4 measured ρ ≈ 0.1 for exactly
    that configuration).  Varying what each member can represent, and how hard it
    is pushed on multi-step prediction, is the cheap way to decorrelate them.
    """
    specs = specs if specs is not None else HETERO_SPECS
    models = []
    for i in range(base_cfg.n_ensemble):
        spec = specs[i % len(specs)]
        cfg = copy.deepcopy(base_cfg)
        for key, value in spec.items():
            setattr(cfg, key, value)
        cfg.seed = base_cfg.seed + 100 * i

        log_cfg = copy.deepcopy(log_cfgs[i % len(log_cfgs)])
        log = generate_log(sim, log_cfg)
        if verbose:
            print(f"  [hetero {i + 1}/{base_cfg.n_ensemble}] {spec}")
        models.append(train_world_model(sim, log, cfg, device, verbose=verbose))
    return models
