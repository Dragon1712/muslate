"""Offline interaction-log generation.

The log is what a real offline recommender dataset would give us: for each
(episode, step) we see the *ordered slate* that was shown and the *scalar
reward* that came back.  The user's latent state is NOT observed -- it is
recorded separately only so that the ``oracle_state`` world model can be
trained as a reference point.

The logging policy is a temperature-controlled myopic greedy with epsilon
exploration, i.e. realistic: competent enough to be informative, biased enough
that naive off-policy evaluation is misleading.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from muslate.config import LogConfig
from muslate.env.simulator import SlateSim


@dataclass
class OfflineLog:
    episode_ids: np.ndarray   # [T] int
    step_ids: np.ndarray      # [T] int
    slates: np.ndarray        # [T, K] int
    rewards: np.ndarray       # [T] float
    states: np.ndarray        # [T, D] ground-truth latent (h, sat)
    n_items: int
    slate_size: int
    horizon: int

    def __len__(self) -> int:
        return self.slates.shape[0]

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            path,
            episode_ids=self.episode_ids,
            step_ids=self.step_ids,
            slates=self.slates,
            rewards=self.rewards,
            states=self.states,
            meta=np.asarray([self.n_items, self.slate_size, self.horizon], dtype=np.int64),
        )

    @classmethod
    def load(cls, path: str | Path) -> "OfflineLog":
        d = np.load(path)
        n_items, slate_size, horizon = d["meta"].tolist()
        return cls(
            episode_ids=d["episode_ids"],
            step_ids=d["step_ids"],
            slates=d["slates"],
            rewards=d["rewards"],
            states=d["states"],
            n_items=int(n_items),
            slate_size=int(slate_size),
            horizon=int(horizon),
        )


def generate_log(sim: SlateSim, cfg: LogConfig) -> OfflineLog:
    rng = np.random.default_rng(cfg.seed + 4242)

    ep_ids, steps, slates, rewards, states = [], [], [], [], []
    for e in range(cfg.n_episodes):
        user = int(rng.integers(sim.cfg.n_users))
        state = sim.initial_state(user, np.random.default_rng(cfg.seed * 7919 + e))
        for t in range(sim.cfg.horizon):
            slate = sim.behavior_slate(
                state.h, state.sat, rng, epsilon=cfg.epsilon, temperature=cfg.temperature
            )
            states.append(np.concatenate([state.h, state.sat]))
            slates.append(slate)
            r, state = sim.step(state, slate, rng, noise=True)
            ep_ids.append(e)
            steps.append(t)
            rewards.append(r)

    return OfflineLog(
        episode_ids=np.asarray(ep_ids, dtype=np.int64),
        step_ids=np.asarray(steps, dtype=np.int64),
        slates=np.asarray(slates, dtype=np.int64),
        rewards=np.asarray(rewards, dtype=np.float64),
        states=np.asarray(states, dtype=np.float64),
        n_items=sim.n_items,
        slate_size=sim.slate_size,
        horizon=sim.cfg.horizon,
    )
