import sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tests import test_pilot_analysis as fixtures
from scripts.analyze_logged_pilot import validate_results,select_weights


class ResultIntegrityTests(unittest.TestCase):
    def test_version2_rejects_illegal_recorded_action_and_future_depth(self):
        from muslate.eval.integrity import validate_protocols
        from muslate.planning.cost import PlanningCost
        from dataclasses import asdict
        r=copy.deepcopy(fixtures.AnalysisTests().fixture()[0]);settings=r['identity']['config'];settings['protocol_version']=2
        for split in r['protocols'].values():
            for p in split.values():
                for row in p['rows'].values():
                    row['decisions']=[dict(user_id=u,t=t,remaining_steps=20-t,effective_depth=min(2,19-t),
                        slate=[0,1,2,3,4],reward=0.,cost=asdict(PlanningCost()),estimated_compute_ms=0.) for u in (0,1) for t in range(20)]
        r['protocols']['validation']['full_episode']['rows']['sid_hier']['decisions'][0]['slate']=[0,0,2,3,4]
        with self.assertRaises(ValueError):validate_protocols(r['protocols'],settings)

    def test_incomplete_completed_run_is_not_silently_skipped(self):
        import tempfile,json
        from scripts.run_logged_pilot import claim_run
        identity={'config':{'epochs':1},'source':{'x':'y'}}
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);claim_run(root,identity)
            (root/'result.json').write_text(json.dumps({'identity':identity,'status':'complete'}))
            with self.assertRaises(ValueError):claim_run(root,identity)

    def test_mean_mismatch_is_rejected_before_validation_selection(self):
        results=copy.deepcopy(fixtures.AnalysisTests().fixture())
        results[1]['protocols']['validation']['common_prefix']['rows']['sid_hier']['return_mean']=1e100
        with self.assertRaises(ValueError):validate_results(results)
        with self.assertRaises(ValueError):select_weights(results)

    def test_tail_must_sum_with_prefix_to_total_return(self):
        results=copy.deepcopy(fixtures.AnalysisTests().fixture())
        row=results[0]['protocols']['test']['common_prefix']['rows']['sid_hier']
        row['tail_returns']=[-999.,-999.]
        with self.assertRaises(ValueError):validate_results(results)

    def test_missing_planner_and_split_fail_explicitly(self):
        for missing in ('planner','split'):
            results=copy.deepcopy(fixtures.AnalysisTests().fixture())
            if missing=='split':del results[0]['protocols']['test']
            else:del results[0]['protocols']['validation']['common_prefix']['rows']['reactive']
            with self.assertRaises(ValueError):validate_results(results)


if __name__=='__main__':unittest.main()
